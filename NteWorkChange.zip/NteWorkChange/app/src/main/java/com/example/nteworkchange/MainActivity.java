package com.example.nteworkchange;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private static boolean isNetAvailable=false;     //通过一个boolean变量间接去记录
    private NteWorkChangeReceive nteWorkChangeReceive;
    private IntentFilter intentFilter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        intentFilter=new IntentFilter();
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        nteWorkChangeReceive=new NteWorkChangeReceive();
        registerReceiver(nteWorkChangeReceive,intentFilter);

    }
    class NteWorkChangeReceive extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            ConnectivityManager connectivityManager=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo=connectivityManager.getActiveNetworkInfo();
            if(networkInfo!=null&&networkInfo.isAvailable()){
                if(!isNetAvailable){
                    isNetAvailable=true;
                    Toast.makeText(context, "网络连接", Toast.LENGTH_SHORT).show();

                    Log.d("Receive1", "连接");
                }
            }else {
                if(isNetAvailable){
                    isNetAvailable=false;
                    Toast.makeText(context, "网络断开", Toast.LENGTH_SHORT).show();

                    Log.d("Receive1", "断开");

                }
            }
        }
    }
}
